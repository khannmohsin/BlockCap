# acknowledgement.py
import requests, re
from monitor import track_performance

class AcknowledgementSender:
    """Sends acknowledgment, enode, and required files to the registering node."""

    def __init__(self, registering_node_url, genesis_file, node_registry_file, besu_rpc_url, prefunded_keys_file):
        self.registering_node_url = registering_node_url.rstrip("/")
        self.genesis_file = genesis_file
        self.node_registry_file = node_registry_file
        self.besu_rpc_url = besu_rpc_url
        self.prefunded_keys_file = prefunded_keys_file

    @track_performance
    def get_enode(self):
        payload = {"jsonrpc":"2.0","method":"admin_nodeInfo","params":[],"id":1}
        try:
            r = requests.post(self.besu_rpc_url, json=payload, headers={"Content-Type":"application/json"})
            data = r.json()
            enode_url = data.get("result", {}).get("enode", "")
            if enode_url and re.match(r"^enode://[a-fA-F0-9]+@[\d.]+:\d+", enode_url):
                return enode_url
        except requests.RequestException as e:
            print(f"Error fetching enode: {e}")
        return None

    @track_performance
    def send_acknowledgment(self, node_id: str) -> bool:
        enode = self.get_enode()
        if not enode:
            print("Error: enode could not be retrieved!")
            return False

        data = {"node_id": node_id, "enode": enode}
        files = {
            "genesis_file": open(self.genesis_file, "rb"),
            "node_registry_file": open(self.node_registry_file, "rb"),
            "prefunded_keys_file": open(self.prefunded_keys_file, "rb"),
        }
        try:
            resp = requests.post(f"{self.registering_node_url}/acknowledgement", data=data, files=files)
            if resp.status_code == 200:
                print(f"Acknowledgment sent to {self.registering_node_url} for node {node_id}")
                return True
            print(f"Ack HTTP {resp.status_code}: {resp.text}")
            return False
        except Exception as e:
            print(f"Error sending acknowledgment: {e}")
            return False
        finally:
            for f in files.values():
                try: f.close()
                except: pass