#!/bin/bash
# orchestration_cli.sh
# One CLI for:
# - Blockchain lifecycle (root)
# - Orchestration API (root-only vs client-facing)
# - Simple wrappers around REST endpoints exposed by orchestration_service.py

# =========[ CONFIG ]=========
ROOT_PATH="$(pwd)"
ROOT_PATH_PYTHON="$(dirname "$(pwd)")"
PYTHON_V_ENV="$ROOT_PATH_PYTHON/.venv/bin/python"

# Default root API server & chain
OWNER_HOST="127.0.0.1"
OWNER_PORT="${OWNER_PORT:-8080}"
OWNER_API="http://$OWNER_HOST:$OWNER_PORT"

FLASK_PORT=5000      # legacy, used by self-register helper
BESU_PORT=8545
Naked_IP_ADD=127.0.0.1
IP_ADDRESS=http://127.0.0.1

NODE_URL=$IP_ADDRESS:$FLASK_PORT
BESU_RPC_URL=$IP_ADDRESS:$BESU_PORT

BLOCKCHAIN_SCRIPT="$ROOT_PATH/root_blockchain_init.py"
FLASK_SCRIPT="$ROOT_PATH/orchestration_service.py"

SOURCE_FILE="$ROOT_PATH/smart_contract_deployment/build/contracts/NodeRegistry.json"
DESTINATION_DIR="$ROOT_PATH/data"

# Orchestrator env toggles (export before calling if you want different behavior)
export REAL_INTERACT="${REAL_INTERACT:-1}"   # talk to real interact.js by default
export ORCH_TRACE="${ORCH_TRACE:-0}"         # set 1 to see node commands
export FROM_IDX="${FROM_IDX:-0}"             # signer index for interact.js

# =========[ COLORS ]=========
RED="\033[31m"; GREEN="\033[32m"; YELLOW="\033[33m"; BLUE="\033[34m"; CYAN="\033[36m"; RESET="\033[0m"

# =========[ UI HELPERS ]=========
print_header() { echo -e "\n${BLUE}========== $1 ==========${RESET}"; }
success() { echo -e "${GREEN}[✔] $1${RESET}"; }
error()   { echo -e "${RED}[✘] $1${RESET}"; }
warn()    { echo -e "${YELLOW}[!] $1${RESET}"; }

# =========[ OWNER: BLOCKCHAIN / SERVICE ]=========
root_start_service() {
  print_header "Starting Orchestration API (Owner)"
  osascript -e "tell application \"Terminal\" to do script \"$PYTHON_V_ENV $FLASK_SCRIPT --host 0.0.0.0 --port $OWNER_PORT --repo-root $ROOT_PATH\""
  success "API starting on $OWNER_API"
}

root_health() {
  print_header "Owner Health"
  curl -s "$OWNER_API/health" | jq .
}

root_initialize_blockchain() {
  print_header "Initializing Blockchain Root"

  [ -f "$ROOT_PATH/qbftConfigFile.json" ] && warn "qbftConfigFile.json exists" \
    || $PYTHON_V_ENV "$BLOCKCHAIN_SCRIPT" create_qbft_file 3 1

  [ -f "$ROOT_PATH/data/key.priv" ] && [ -f "$ROOT_PATH/data/key.pub" ] && warn "Keys exist" \
    || $PYTHON_V_ENV "$BLOCKCHAIN_SCRIPT" generate_keys

  [ -f "$ROOT_PATH/genesis/genesis.json" ] && warn "genesis.json exists" \
    || $PYTHON_V_ENV "$BLOCKCHAIN_SCRIPT" create_genesis_file "$ROOT_PATH/qbftConfigFile.json"

  [ -f "$ROOT_PATH/genesis/validator_address.json" ] && warn "validator_address.json exists" \
    || $PYTHON_V_ENV "$BLOCKCHAIN_SCRIPT" update_genesis_file

  [ -f "$ROOT_PATH/genesis/extraData.rlp" ] && warn "extraData.rlp exists" \
    || $PYTHON_V_ENV "$BLOCKCHAIN_SCRIPT" update_extra_data_in_genesis

  success "Blockchain init complete"
}

root_start_chain() {
  print_header "Starting Blockchain"
  osascript -e "tell application \"Terminal\" to do script \"$PYTHON_V_ENV $BLOCKCHAIN_SCRIPT start_blockchain_node $Naked_IP_ADD\""
  sleep 3
  pgrep -f besu >/dev/null && success "Blockchain node started" || error "Failed to start blockchain"
}

root_stop_chain() {
  print_header "Stopping Blockchain"
  pkill -f "besu" && success "Blockchain stopped" || warn "No blockchain process found"
}

root_restart_chain() {
  print_header "Restarting Blockchain"
  root_stop_chain
  sleep 2
  root_start_chain
}

root_reinit_chain() {
  print_header "Reinitializing Blockchain Root"
  rm -rf "$ROOT_PATH/data" "$ROOT_PATH/genesis" "$ROOT_PATH/qbftConfigFile.json" "$ROOT_PATH/prefunded_keys.json" "$ROOT_PATH/node-details.json"
  root_initialize_blockchain
}

root_deploy_contract() {
  print_header "Deploying Smart Contract"
  read -rp "Enter private key for deployment: " private_key
  [ -z "$private_key" ] && { error "Private key required"; exit 1; }
  bash "$ROOT_PATH/smart_contract_deployment/compile_deploy_contract.sh" "$private_key"
  [ -f "$SOURCE_FILE" ] && cp "$SOURCE_FILE" "$DESTINATION_DIR" && success "Contract deployed & copied" \
    || error "Deployed contract artifact not found"
}

# =========[ OWNER: ORCHESTRATION OPS ]=========

root_node_info() {
  local signature="$1"
  [ -z "$signature" ] && { error "Usage: $0 root-node-info <signature>"; exit 1; }
  print_header "Node Details (Owner)"
  curl -s "$OWNER_API/node/$signature" | jq .
}

root_validators() {
  print_header "Validators (Owner)"
  curl -s "$OWNER_API/validators" | jq .
}

root_revoke_grant() {
  local from_sig="$1" to_sig="$2"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 root-revoke-grant <from_sig> <to_sig>"; exit 1; }
  print_header "Revoke Grant (Owner)"
  curl -s -X POST "$OWNER_API/revoke-grant" -H "Content-Type: application/json" \
    -d "{\"from_signature\":\"$from_sig\",\"to_signature\":\"$to_sig\"}" | jq .
}

root_delegate() {
  local parent_from="$1" to_sig="$2" child_from="$3" ops_csv="$4" child_expiry="${5:-600}"
  [ -z "$parent_from" ] || [ -z "$to_sig" ] || [ -z "$child_from" ] || [ -z "$ops_csv" ] && {
    error "Usage: $0 root-delegate <parent_from_sig> <to_sig> <child_from_sig> <ops_csv> [child_expiry_secs]"
    exit 1
  }
  print_header "Delegate Grant (Owner / current grant holder)"
  curl -s -X POST "$OWNER_API/delegate" -H "Content-Type: application/json" \
    -d "{\"parent_from_sig\":\"$parent_from\",\"to_sig\":\"$to_sig\",\"child_from_sig\":\"$child_from\",\"ops_csv\":\"$ops_csv\",\"child_expiry_secs\":$child_expiry}" | jq .
}

root_grant_info() {
  local from_sig="$1" to_sig="$2"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 root-grant-info <from_sig> <to_sig>"; exit 1; }
  print_header "Grant Info (Owner)"
  curl -s "$OWNER_API/grant?from_signature=$from_sig&to_signature=$to_sig" | jq .
}

register() {
  print_header "Smart Registration (POST /register-node)"

  local node_id="$1"
  local node_name="$2"
  local node_type="$3"              # e.g., Cloud|Fog|Edge|Sensor|Actuator
  local wants="${4:-auto}"          # true|false|auto

  if [ -z "$node_id" ] || [ -z "$node_name" ] || [ -z "$node_type" ]; then
    error "Usage: $0 register <node_id> <node_name> <node_type> [wants_validator:true|false|auto]"
    return 1
  fi

  # API base (your orchestration_service)
  local host="${OWNER_HOST:-127.0.0.1}"
  local port="${OWNER_PORT:-8080}"
  local api_base="http://$host:$port"

  # Key paths + RPC
  local pub_path="$ROOT_PATH/data/key.pub"
  local priv_path="$ROOT_PATH/data/key.priv"
  local rpc_url="${BESU_RPC_URL:-http://127.0.0.1:8545}"

  if [ ! -f "$pub_path" ] || [ ! -f "$priv_path" ]; then
    error "Missing $pub_path or $priv_path. Run root-init-chain first."
    return 1
  fi

  # Resolve wants_validator if "auto":
  # heuristic: Cloud/Fog => true, else false. If /validators reachable and our address is in it, force true.
  local wants_bool
  if [ "$wants" = "auto" ]; then
    wants_bool=false
    case "$node_type" in
      Cloud|Fog) wants_bool=true ;;
    esac
    # If we can prove we’re (already) a validator, force true
    if curl -fsS "$api_base/validators" >/dev/null 2>&1; then
      # get our address using node_identity
      my_addr="$($PYTHON_V_ENV "$ROOT_PATH/node_identity.py" address "$priv_path" 2>/dev/null || true)"
      if [ -n "$my_addr" ] && curl -fsS "$api_base/validators" | grep -qi "$(echo "$my_addr" | tr '[:upper:]' '[:lower:]')" ; then
        wants_bool=true
      fi
    fi
  else
    wants_bool=$( [ "$wants" = "true" ] && echo true || echo false )
  fi

  # Build identity bundle JSON (also writes node-details.json for you)
  local bundle_json
  bundle_json="$($PYTHON_V_ENV "$ROOT_PATH/node_identity.py" bundle \
    "$node_id" "$node_name" "$node_type" "$pub_path" "$priv_path" "$rpc_url" "$wants_bool")" || {
      error "Failed to build identity bundle"
      return 1
    }

  # Pretty print what we’re sending
  echo "POST -> $api_base/register-node"
  if command -v jq >/dev/null 2>&1; then echo "$bundle_json" | jq .; else echo "$bundle_json"; fi

  # Send registration
  curl -s -X POST "$api_base/register-node" \
    -H "Content-Type: application/json" \
    -d "$bundle_json" | (command -v jq >/dev/null 2>&1 && jq . || cat)

  success "Registration sent. node-details.json updated."
}


# =========[ CLIENT (OTHER NODES): REGISTRATION + ACCESS ]=========
# client_register_node() {
#   # Modes:
#   # 1) Raw values:
#   #    client-register <id> <name> <type> <public_key> <address> <rpcURL> <signature> [wants_validator]
#   # 2) Using local keys:
#   #    client-register --use-keys <id> <name> <type> [rpcURL] [wants_validator]
#   #
#   local api="$OWNER_API"

#   if [ "$1" = "--use-keys" ]; then
#     shift
#     local node_id="$1" node_name="$2" node_type="$3" rpc="${4:-$BESU_RPC_URL}" wants="${5:-false}"
#     local pub_path="$ROOT_PATH/data/key.pub"
#     local priv_path="$ROOT_PATH/data/key.priv"
#     [ -f "$pub_path" ] && [ -f "$priv_path" ] || { error "Missing $pub_path or $priv_path"; exit 1; }

#     local bundle_json
#     bundle_json="$($PYTHON_V_ENV "$ROOT_PATH/node_identity.py" bundle "$node_id" "$node_name" "$node_type" "$pub_path" "$priv_path" "$rpc" "$wants")" || {
#       error "Failed to build identity bundle"
#       exit 1
#     }
#     print_header "Client → Register Node @ Owner (use-keys)"
#     curl -s -X POST "$api/register-node" -H "Content-Type: application/json" -d "$bundle_json" \
#       | (command -v jq >/dev/null 2>&1 && jq . || cat)
#     return
#   fi

#   # Raw mode
#   local node_id="$1" node_name="$2" node_type="$3" public_key="$4" address="$5" rpcURL="$6" signature="$7" wants="${8:-false}"
#   if [ -z "$node_id" ] || [ -z "$node_name" ] || [ -z "$node_type" ] || [ -z "$public_key" ] || [ -z "$address" ] || [ -z "$rpcURL" ] || [ -z "$signature" ]; then
#     error "Usage: $0 client-register <id> <name> <type> <pubkey> <address> <rpcURL> <signature> [wants_validator]  OR  $0 client-register --use-keys <id> <name> <type> [rpcURL] [wants]"
#     exit 1
#   fi
#   print_header "Client → Register Node @ Owner"
#   curl -s -X POST "$api/register-node" -H "Content-Type: application/json" \
#     -d "{\"node_id\":\"$node_id\",\"node_name\":\"$node_name\",\"node_type\":\"$node_type\",\"public_key\":\"$public_key\",\"address\":\"$address\",\"rpcURL\":\"$rpcURL\",\"signature\":\"$signature\",\"wants_validator\":$wants}" \
#     | (command -v jq >/dev/null 2>&1 && jq . || cat)
# }

client_access() {
  # Generic /access (POST), usually not needed if you use the simple endpoints
  local from_sig="$1" to_sig="$2" method="$3" path="$4" expiry="${5:-900}" allow="${6:-false}" depth="${7:-0}"
  if [ -z "$from_sig" ] || [ -z "$to_sig" ] || [ -z "$method" ] || [ -z "$path" ]; then
    error "Usage: $0 client-access <from_sig> <to_sig> <METHOD> </resource_path> [expiry_secs] [allow_delegation(true|false)] [delegation_depth]"
    exit 1
  fi
  print_header "Client → /access"
  curl -s -X POST "$OWNER_API/access" -H "Content-Type: application/json" \
    -d "{\"from_signature\":\"$from_sig\",\"to_signature\":\"$to_sig\",\"method\":\"$method\",\"resource_path\":\"$path\",\"expiry_secs\":$expiry,\"allow_delegation\":$allow,\"delegation_depth\":$depth}" | jq .
}

# ----- Convenience “simple endpoints” the client should use -----
# They match the root’s routes that internally call access_flow using query params.

client_temperature_read() {
  local from_sig="$1" to_sig="$2" path="${3:-/temperature}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 temp-read <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → GET $path"
  curl -s -X GET "$OWNER_API/temperature?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_temperature_write() {
  local from_sig="$1" to_sig="$2" path="${3:-/temperature}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 temp-write <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → POST $path"
  curl -s -X POST "$OWNER_API/temperature?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_firmware_update() {
  local from_sig="$1" to_sig="$2" path="${3:-/firmware}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 fw-update <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → PUT $path"
  curl -s -X PUT "$OWNER_API/firmware?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_firmware_remove() {
  local from_sig="$1" to_sig="$2" path="${3:-/firmware}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 fw-remove <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → DELETE $path"
  curl -s -X DELETE "$OWNER_API/firmware?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_alerts_read() {
  local from_sig="$1" to_sig="$2" path="${3:-/alerts}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 alerts-read <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → GET $path"
  curl -s -X GET "$OWNER_API/alerts?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_alerts_create() {
  local from_sig="$1" to_sig="$2" path="${3:-/alerts}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 alerts-create <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → POST $path"
  curl -s -X POST "$OWNER_API/alerts?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_control_led() {
  local from_sig="$1" to_sig="$2" path="${3:-/control/led}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 control-led <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → PUT $path"
  curl -s -X PUT "$OWNER_API/control/led?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

client_control_motor_stop() {
  local from_sig="$1" to_sig="$2" path="${3:-/control/motor}"
  [ -z "$from_sig" ] || [ -z "$to_sig" ] && { error "Usage: $0 control-motor-stop <from_sig> <to_sig> [/resource_path]"; exit 1; }
  print_header "Client → DELETE $path"
  curl -s -X DELETE "$OWNER_API/control/motor?from_signature=$from_sig&to_signature=$to_sig&resource_path=$path" | jq .
}

# =========[ HELP ]=========
show_help() {
  echo -e "${CYAN}Usage:${RESET} $0 <command> [args]"
  echo
  echo -e "${CYAN}Owner: Service & Chain${RESET}"
  echo "  root-start-service                 Start orchestration Flask API on $OWNER_API"
  echo "  root-health                        Check /health"
  echo "  root-init-chain                    Initialize blockchain root (keys/genesis/extraData)"
  echo "  root-start-chain                   Start blockchain process"
  echo "  root-stop-chain                    Stop blockchain process"
  echo "  root-restart-chain                 Restart blockchain"
  echo "  root-reinit-chain                  Wipe and re-init chain data"
  echo "  root-deploy-contract               Compile/deploy smart contract and copy artifact"
  echo "  root-node-register <node_id> <node_name> <node_type> <wants_validator:true|false>  Self-register root node"
  echo
  echo -e "${CYAN}Owner: Orchestration Ops (device root only)${RESET}"
  echo "  root-node-info <signature>         Show on-chain node details"
  echo "  root-validators                    Show validator set"
  echo "  root-revoke-grant <from> <to>      Revoke a grant"
  echo "  root-delegate <parent> <to> <child> <ops_csv> [expiry]   Delegate grant"
  echo "  root-grant-info <from> <to>        Read grant info"
  echo
  echo -e "${CYAN}Client (Other Nodes): Registration + Access${RESET}"
  echo "  client-register <id> <name> <type> <pubkey> <address> <rpcURL> <signature> [wants_validator]"
  echo "  client-access <from> <to> <METHOD> </path> [expiry] [allow_delegation] [depth]"
  echo "  temp-read <from> <to> [/path]       GET /temperature"
  echo "  temp-write <from> <to> [/path]      POST /temperature"
  echo "  fw-update <from> <to> [/path]       PUT /firmware"
  echo "  fw-remove <from> <to> [/path]       DELETE /firmware"
  echo "  alerts-read <from> <to> [/path]     GET /alerts"
  echo "  alerts-create <from> <to> [/path]   POST /alerts"
  echo "  control-led <from> <to> [/path]     PUT /control/led"
  echo "  control-motor-stop <from> <to> [/path]  DELETE /control/motor"
  echo
  echo -e "${CYAN}Env toggles (export before running):${RESET}"
  echo "  REAL_INTERACT=1   talk to chain via interact.js (default 1)"
  echo "  ORCH_TRACE=1      print interact.js calls"
  echo "  FROM_IDX=0        signer index used by interact.js"
  echo "  OWNER_PORT=8080   port for orchestration_service"
}

# =========[ DISPATCH ]=========
cmd="$1"; shift || true
case "$cmd" in
  # Owner: service/chain
  root-start-service) root_start_service ;;
  root-health) root_health ;;
  root-init-chain) root_initialize_blockchain ;;
  root-start-chain) root_start_chain ;;
  root-stop-chain) root_stop_chain ;;
  root-restart-chain) root_restart_chain ;;
  root-reinit-chain) root_reinit_chain ;;
  root-deploy-contract) root_deploy_contract ;;
  register) register "$@" ;;

  # Owner: orchestration ops
  root-node-info) root_node_info "$@" ;;
  root-validators) root_validators ;;
  root-revoke-grant) root_revoke_grant "$@" ;;
  root-delegate) root_delegate "$@" ;;
  root-grant-info) root_grant_info "$@" ;;

  # Client: registration + access
#   client-register) client_register_node "$@" ;;
  client-access) client_access "$@" ;;
  temp-read) client_temperature_read "$@" ;;
  temp-write) client_temperature_write "$@" ;;
  fw-update) client_firmware_update "$@" ;;
  fw-remove) client_firmware_remove "$@" ;;
  alerts-read) client_alerts_read "$@" ;;
  alerts-create) client_alerts_create "$@" ;;
  control-led) client_control_led "$@" ;;
  control-motor-stop) client_control_motor_stop "$@" ;;

  help|"") show_help ;;
  *) error "Unknown command: $cmd"; show_help; exit 1 ;;
esac