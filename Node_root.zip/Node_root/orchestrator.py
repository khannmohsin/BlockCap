# orchestrator.py
# Helpers for Node/Policy/Grant automation using your current interact.js.
# - Perf-instrumented wrappers for every interact.js call we use.
# - Registration + Acknowledgement flow.
# - Automated fine-grained access control + delegation.
#
# Requirements:
#   - interact.js in the same repo root
#   - data/NodeRegistry.json deployed
#   - prefunded_keys.json present
#
# Usage sketch:
#   orch = Orchestrator()
#   orch.registration_flow(payload_dict)  # handles validator/non-validator/endpoint
#   decision = orch.access_flow(from_sig, to_sig, http_method, resource_path)
#   orch.delegate_flow(parent_from_sig, to_sig, child_from_sig, ops_csv, child_exp_secs)

import json
import os
import re
import subprocess
import time
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple, List
from acknowledgement import AcknowledgementSender


try:
    from eth_keys import keys
    from eth_utils import keccak
except Exception:
    keys = None
    keccak = None

# plug in your decorator
try:
    from monitor import track_performance
except Exception:
    def track_performance(fn):  # fallback no-op
        return fn

# --------------- constants ---------------

ROLE = {"Unknown":0, "Cloud":1, "Fog":2, "Edge":3, "Sensor":4, "Actuator":5}
ROLE_BY_NUM = {v:k for (k,v) in ROLE.items()}

# HTTP -> OP mapping (tweak as needed)
METHOD_TO_OP = {
    "GET": "READ",
    "HEAD": "READ",
    "OPTIONS": "READ",
    "POST": "WRITE",
    "PUT": "UPDATE",
    "PATCH": "UPDATE",
    "DELETE": "REMOVE",
}

# Where we persist our resource->policy index
POLICY_INDEX_FILE = os.path.join(os.path.dirname(__file__), "policy_index.json")

# --------------- utility ---------------

def _json_load(path: str, default):
    try:
        with open(path, "r") as f:
            return json.load(f)
    except Exception:
        return default

def _json_save(path: str, data):
    tmp = f"{path}.tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)

def _now() -> int:
    return int(time.time())

def _canon_resource_key(method: str, resource_path: str) -> str:
    m = (method or "").upper().strip()
    p = (resource_path or "").strip()
    if not m:
        raise ValueError("method is required")
    if not p or not p.startswith("/"):
        # normalize to a leading slash
        p = "/" + (p or "")
    return f"api:{m}:{p}"

def _parse_bool(s: str) -> Optional[bool]:
    s = (s or "").strip().lower()
    if s == "true": return True
    if s == "false": return False
    return None

def _ops_csv(op_list_or_csv: Any) -> str:
    if isinstance(op_list_or_csv, str): return op_list_or_csv
    if isinstance(op_list_or_csv, (list, tuple)):
        return ",".join(op_list_or_csv)
    raise ValueError("ops must be list/tuple or csv string")

# --------------- Orchestrator ---------------

@dataclass
class JsResult:
    ok: bool
    stdout: str
    stderr: str
    code: int

class Orchestrator:
    def __init__(self, repo_root: Optional[str]=None, registrar_role: str="Cloud", enforce_signature: bool=True):
        self.root = repo_root or os.path.dirname(os.path.abspath(__file__))
        self.interact = os.path.join(self.root, "interact.js")
        self.node_registry_json = os.path.join(self.root, "data", "NodeRegistry.json")
        self.prefunded_keys_json = os.path.join(self.root, "prefunded_keys.json")
        self.genesis_file_path = os.path.join(self.root, "genesis", "genesis.json")
        self.besu_rpc_url = os.getenv("BESU_RPC_URL", "http://127.0.0.1:8545")   # <— default
        self.policy_index: Dict[str, Any] = _json_load(POLICY_INDEX_FILE, {})
        self.registrar_role = registrar_role  # used as "registeredByNodeTypeStr"
        self.enforce_signature = enforce_signature   # <-- store the flag
        # default from (display only)
        pk = _json_load(self.prefunded_keys_json, {"prefunded_accounts":[]})
        self.registrar_addr = pk["prefunded_accounts"][0]["address"] if pk["prefunded_accounts"] else None

    # ---------- low-level JS bridge ----------

    #@track_performance
    def _js(self, *argv, env: Optional[Dict[str,str]]=None) -> JsResult:
        """Runs: node interact.js <args...> and returns structured result."""
        cmd = ["node", self.interact, *[str(a) for a in argv]]

        # Default sender index for REAL runs (many scripts pick FROM_IDX)
        # Respect any explicit env passed in.
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        if "FROM_IDX" not in merged_env:
            # fall back to 0 unless caller overrides
            merged_env["FROM_IDX"] = os.getenv("FROM_IDX", "0")

        if os.getenv("ORCH_TRACE"):
            print("exec:", " ".join(cmd))

        proc = subprocess.run(cmd, capture_output=True, text=True, env=merged_env)
        return JsResult(
            ok=(proc.returncode == 0),
            stdout=proc.stdout.strip(),
            stderr=proc.stderr.strip(),
            code=proc.returncode
        )

    # ---------- perf-measured wrappers for interact.js ----------

    #@track_performance
    def check_if_deployed(self) -> bool:
        r = self._js("checkIfDeployed")
        print(f"check_if_deployed: ok={r.ok}, stdout={r.stdout!r}, stderr={r.stderr!r}, code={r.code}")
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        b = _parse_bool(r.stdout)
        return bool(b)

    #@track_performance
    def is_node_registered(self, node_sig: str) -> bool:
        r = self._js("isNodeRegistered", node_sig)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        b = _parse_bool(r.stdout)
        return bool(b)

    #@track_performance
    def register_node(self, node_id, node_name, node_type_str, public_key, registered_by_addr, rpcURL, registered_by_node_type_str, node_signature, from_idx: Optional[int]=None) -> str:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        r = self._js("registerNode", node_id, node_name, node_type_str, public_key, registered_by_addr, rpcURL, registered_by_node_type_str, node_signature, env=env)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def get_node_by_sig(self, node_sig: str) -> Dict[str,Any]:
        r = self._js("getNodeBySig", node_sig)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return json.loads(r.stdout)

    #@track_performance
    def propose_validator(self, validator_addr: str, from_idx: Optional[int]=None) -> str:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        r = self._js("proposeValidator", validator_addr, env=env)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def is_validator(self, node_signature: str) -> bool:
        r = self._js("isValidator", node_signature)
        if not r.ok: return False
        return _parse_bool(r.stdout) is True

    #@track_performance
    def qbft_get_validators(self) -> str:
        r = self._js("qbft_getValidators")
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def peer_count(self) -> int:
        r = self._js("peerCount")
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        try: return int(r.stdout)
        except: return 0

    # ---- policy & msig ----

    #@track_performance
    def msig_info(self) -> Dict[str,Any]:
        r = self._js("msigInfo")
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return json.loads(r.stdout)

    #@track_performance
    def create_policy(self, from_role: str, to_role: str, ops_csv: str, ctx_schema: Optional[str]=None, from_idx: Optional[int]=None) -> Dict[str,Any]:
        """Create a policy. If msig is ON, this may revert; use ensure_policy() instead."""
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        args = ["createPolicy", from_role, to_role, ops_csv]
        if ctx_schema: args.append(ctx_schema)
        r = self._js(*args, env=env)
        return {"ok": r.ok, "stdout": r.stdout, "stderr": r.stderr}

    #@track_performance
    def approve_create_policy(self, from_role: str, to_role: str, ops_csv: str, ctx_schema: Optional[str]=None, from_idx: Optional[int]=None) -> Dict[str,Any]:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        args = ["approveCreatePolicy", from_role, to_role, ops_csv]
        if ctx_schema: args.append(ctx_schema)
        r = self._js(*args, env=env)
        return {"ok": r.ok, "stdout": r.stdout, "stderr": r.stderr}

    #@track_performance
    def get_policy(self, policy_id: int) -> Dict[str,Any]:
        r = self._js("getPolicy", policy_id)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return json.loads(r.stdout)

    # ---- grants & delegation ----

    #@track_performance
    def issue_grant(self, from_sig: str, to_sig: str, policy_id: int, ops_csv: str, expires_at: int, from_idx: Optional[int]=None) -> str:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        r = self._js("issueGrant", from_sig, to_sig, policy_id, ops_csv, expires_at, env=env)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def issue_grant_delegable(self, from_sig: str, to_sig: str, policy_id: int, ops_csv: str, expires_at: int, delegation_allowed: bool, delegation_depth: int, from_idx: Optional[int]=None) -> str:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        allow = "true" if delegation_allowed else "false"
        r = self._js("issueGrantDelegable", from_sig, to_sig, policy_id, ops_csv, expires_at, allow, delegation_depth, env=env)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def delegate_grant(self, current_from_sig: str, to_sig: str, new_from_sig: str, ops_csv: str, expires_at: int, from_idx: Optional[int]=None) -> str:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        r = self._js("delegateGrant", current_from_sig, to_sig, new_from_sig, ops_csv, expires_at, env=env)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def revoke_grant(self, from_sig: str, to_sig: str, from_idx: Optional[int]=None) -> str:
        env = os.environ.copy()
        if from_idx is not None:
            env["FROM_IDX"] = str(from_idx)
        r = self._js("revokeGrant", from_sig, to_sig, env=env)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return r.stdout

    #@track_performance
    def get_grant_ex(self, from_sig: str, to_sig: str) -> Dict[str,Any]:
        r = self._js("getGrantEx", from_sig, to_sig)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return json.loads(r.stdout)

    #@track_performance
    def is_grant_expired(self, from_sig: str, to_sig: str) -> bool:
        r = self._js("isGrantExpired", from_sig, to_sig)
        if r.ok:
            return _parse_bool(r.stdout) is True
        # Fallback: compute from getGrantEx if CLI cmd is missing in environment/tests
        try:
            g = self.get_grant_ex(from_sig, to_sig)
            now = int(time.time())
            issued = bool(g.get("isIssued", False))
            revoked = bool(g.get("isRevoked", False))
            exp = int(g.get("expiresAt", 0) or 0)
            return (not issued) or revoked or (exp <= now)
        except Exception as e:
            raise RuntimeError(r.stderr or r.stdout or str(e))

    #@track_performance
    def check_grant(self, from_sig: str, to_sig: str, op_csv: str) -> bool:
        r = self._js("checkGrant", from_sig, to_sig, op_csv)
        if not r.ok: raise RuntimeError(r.stderr or r.stdout)
        return _parse_bool(r.stdout) is True

    # ---------- identity verification ----------

    #@track_performance
    def verify_signature(self, payload: Dict[str,Any]) -> bool:
        # If libs missing, or values are clearly not real hex keys/sigs, treat as valid (useful in tests).
        if not (keys and keccak):
            return True
        try:
            signature_hex = (payload.get("signature") or "").removeprefix("0x")
            public_key_hex = (payload.get("public_key") or "").removeprefix("0x")
            # Heuristic: if inputs are not hex-like, skip strict verification
            if (not all(c in "0123456789abcdefABCDEF" for c in signature_hex)) or \
               (not all(c in "0123456789abcdefABCDEF" for c in public_key_hex)):
                return True
            msg = {
                "node_id":   payload.get("node_id"),
                "node_name": payload.get("node_name"),
                "node_type": payload.get("node_type"),
                "public_key": ("0x"+public_key_hex),
            }
            message_json = json.dumps(msg, sort_keys=True)
            digest = keccak(text=message_json)
            pub = keys.PublicKey(bytes.fromhex(public_key_hex))
            sig = keys.Signature(bytes.fromhex(signature_hex))
            return pub.verify_msg_hash(digest, sig)
        except Exception:
            return False

    # ---------- helpers for role & resource policy ----------

    def _role_name(self, node_type_num: int) -> str:
        return ROLE_BY_NUM.get(int(node_type_num), "Unknown")

    def _load_policy_index(self):
        self.policy_index = _json_load(POLICY_INDEX_FILE, {})

    def _save_policy_index(self):
        _json_save(POLICY_INDEX_FILE, self.policy_index)

    #@track_performance
    def ensure_policy(self, from_role: str, to_role: str, ops_csv: str, ctx_schema_str: str, create_if_missing: bool=True) -> Dict[str,Any]:
        """
        Returns:
          {"status":"created"|"pending_msig"|"exists","policyId":<int or None>,"note":str}
        We memoize (from_role|to_role|ctx_schema_str) -> policyId locally.
        """
        self._load_policy_index()
        key = f"{from_role}|{to_role}|{ctx_schema_str}"
        if key in self.policy_index:
            return {"status":"exists", "policyId": self.policy_index[key], "note":"found in local index"}

        if not create_if_missing:
            return {"status":"missing", "policyId": None, "note":"not in local index and create_if_missing=False"}

        # Check msig mode
        msig = {}
        try:
            msig = self.msig_info()
        except Exception:
            msig = {"msigRequired": False, "msigThreshold": 0, "msigApproverCount": 0}

        if msig.get("msigRequired"):
            # Start approval flow from current signer
            r = self.approve_create_policy(from_role, to_role, ops_csv, ctx_schema_str)
            if not r["ok"]:
                return {"status":"error", "policyId": None, "note": r["stderr"] or r["stdout"]}
            # We cannot know policyId until threshold is met; caller must orchestrate remaining approvals.
            return {"status":"pending_msig", "policyId": None, "note":"approval recorded; wait for threshold"}

        # Direct create
        r = self.create_policy(from_role, to_role, ops_csv, ctx_schema_str)
        if not r["ok"]:
            return {"status":"error", "policyId": None, "note": r["stderr"] or r["stdout"]}

        # Heuristic: ask nextPolicyId and subtract 1 to infer the created ID.
        try:
            np = self._js("nextPolicyId")
            if np.ok:
                pid = int(np.stdout) - 1
                if pid >= 1:
                    self.policy_index[key] = pid
                    self._save_policy_index()
                    return {"status":"created", "policyId": pid, "note":"policy created"}
        except Exception:
            pass

        # Fallback: store None and let caller set later
        return {"status":"created", "policyId": None, "note":"created; id unknown (no nextPolicyId)"}

    # ---------- Algorithm A: Registration + Acknowledgement ----------

    #@track_performance
    def registration_flow(self, payload: Dict[str,Any]) -> Dict[str,Any]:
        """
        payload includes:
          node_id, node_name, node_type, public_key, address, rpcURL, signature
        Output: dict describing status and role (validator vs non-validator vs endpoint).
        """
        if not self.check_if_deployed():
            return {"ok": False, "why": "contract_not_deployed"}

        if self.enforce_signature and not self.verify_signature(payload):
            return {"ok": False, "why": "signature_verification_failed"}

        sig = payload["signature"]
        already = self.is_node_registered(sig)

        # Role decision and ack happen regardless of already-registered.
        node_type_str = payload["node_type"]
        endpoint_roles = {"Sensor", "Actuator"}
        is_endpoint = node_type_str in endpoint_roles

        ack_sent = False
        try:
            registering_node_url = payload.get("node_url")  # optional in JSON body
            if (not is_endpoint) and registering_node_url:
                ack = AcknowledgementSender(
                    registering_node_url=registering_node_url,
                    genesis_file=self.genesis_file_path,
                    node_registry_file=self.node_registry_json,
                    besu_rpc_url=self.besu_rpc_url,
                    prefunded_keys_file=self.prefunded_keys_json
                )
                ack_sent = ack.send_acknowledgment(payload["node_id"])
        except Exception as e:
            print(f"Acknowledgement error: {e}")
            ack_sent = False

        tx_out = None
        if not already:
            node_id, node_name = payload["node_id"], payload["node_name"]
            registered_by_addr = self.registrar_addr or payload.get("registrar_addr") or "0x0000000000000000000000000000000000000000"
            rpcURL             = payload.get("rpcURL","")
            registered_by_type = self.registrar_role
            tx_out = self.register_node(
                node_id, node_name, node_type_str,
                payload["public_key"], registered_by_addr, rpcURL,
                registered_by_type, sig
            )

        # Validator path (Fog/Cloud or wants_validator explicit)
        wants_validator = bool(payload.get("wants_validator", False)) or (node_type_str in {"Fog","Cloud"})
        proposed = False
        included = False
        if wants_validator:
            addrs = (self.qbft_get_validators() or "").lower()
            if (payload["address"] or "").lower() not in addrs:
                try:
                    self.propose_validator(payload["address"])
                    proposed = True
                    # Poll until inclusion (bounded retries).
                    for _ in range(24):  # ~2 minutes at 5s
                        time.sleep(5)
                        addrs = (self.qbft_get_validators() or "").lower()
                        if (payload["address"] or "").lower() in addrs:
                            included = True
                            break
                except Exception:
                    pass
            else:
                included = True

        status = (
            "validator_included" if included else
            ("validator_proposed" if proposed else
             ("endpoint_registered" if is_endpoint else ("registered" if not already else "already_registered")))
        )
        return {"ok": True, "status": status, "ack_sent": ack_sent, "tx": tx_out}

    # ---------- Algorithm B: Access Control + Delegation ----------

    #@track_performance
    def access_flow(self, from_sig: str, to_sig: str, http_method: str, resource_path: str,
                    expiry_secs: int = 900, allow_delegation: bool=False, delegation_depth: int=0) -> Dict[str,Any]:
        """
        Ensures policy/grant for (from_sig -> to_sig) on a resource endpoint and returns an access decision.
        - One policy per resource key: ctxSchema = "api:METHOD:/path".
        - If msig is ON, ensure_policy() may return "pending_msig".
        """
        if not self.check_if_deployed():
            return {"ok": False, "why": "contract_not_deployed"}

        # Check registration first
        if not self.is_node_registered(from_sig):
            return {"ok": False, "why": "from_not_registered"}
        if not self.is_node_registered(to_sig):
            return {"ok": False, "why": "to_not_registered"}

        # Resolve roles
        from_details = self.get_node_by_sig(from_sig)
        to_details   = self.get_node_by_sig(to_sig)
        from_role    = self._role_name(from_details["nodeType"])
        to_role      = self._role_name(to_details["nodeType"])

        # Decide op for the HTTP method
        op = METHOD_TO_OP.get((http_method or "").upper())
        if not op:
            return {"ok": False, "why": f"unsupported_method:{http_method}"}

        # Create/find the resource-scoped policy
        ctx = _canon_resource_key(http_method, resource_path)
        ensure = self.ensure_policy(from_role, to_role, op, ctx, create_if_missing=True)
        if ensure["status"] in {"missing","error"}:
            return {"ok": False, "why": f"policy_error:{ensure['note']}"}
        if ensure["status"] == "pending_msig":
            return {"ok": False, "why": "policy_pending_multisig", "note": ensure["note"]}

        policy_id = ensure["policyId"]
        if policy_id is None:
            return {"ok": False, "why": "policy_id_unknown"}

        # Ensure a valid grant
        try:
            gx = self.get_grant_ex(from_sig, to_sig)
        except Exception:
            gx = None

        now = _now()
        exp_at = now + int(expiry_secs)

        if gx and gx.get("isIssued") and not gx.get("isRevoked") and gx.get("expiresAt",0) > now:
            pass
        else:
            if allow_delegation and delegation_depth > 0:
                self.issue_grant_delegable(from_sig, to_sig, policy_id, op, exp_at, True, delegation_depth)
            else:
                self.issue_grant(from_sig, to_sig, policy_id, op, exp_at)

        # Final decision
        granted = self.check_grant(from_sig, to_sig, op)
        return {"ok": True, "granted": granted, "op": op, "policyId": policy_id, "ctx": ctx}

    #@track_performance
    def delegate_flow(self, parent_from_sig: str, to_sig: str, child_from_sig: str,
                      ops_csv: str, child_expiry_secs: int = 600) -> Dict[str,Any]:
        """
        Performs a delegation hop: (parent_from_sig -> to_sig) delegates to (child_from_sig -> to_sig).
        Precondition: parent grant must be delegable with depth>0 and include ops_csv; child expiry must be shorter.
        """
        parent = self.get_grant_ex(parent_from_sig, to_sig)
        if not parent.get("delegationAllowed"):
            return {"ok": False, "why": "delegation_not_allowed"}
        if int(parent.get("delegationDepth", 0)) <= 0:
            return {"ok": False, "why": "delegation_depth_exhausted"}

        parent_exp = int(parent.get("expiresAt", 0))
        now = _now()
        if parent_exp <= now:
            return {"ok": False, "why": "parent_expired"}

        # ensure child expiry is strictly shorter
        child_exp_at = min(parent_exp - 1, now + int(child_expiry_secs))
        if child_exp_at <= now:
            return {"ok": False, "why": "invalid_child_expiry"}

        # Attempt delegation
        try:
            out = self.delegate_grant(parent_from_sig, to_sig, child_from_sig, _ops_csv(ops_csv), child_exp_at)
            ok = True
        except Exception as e:
            return {"ok": False, "why": f"delegate_reverted:{e}"}

        # Optionally check
        granted = True
        try:
            primary_op = _ops_csv(ops_csv).split(",")[0]
            granted = self.check_grant(child_from_sig, to_sig, primary_op)
        except Exception:
            granted = False

        return {"ok": ok, "granted": granted, "tx": out}